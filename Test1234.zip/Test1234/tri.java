import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

public class tri extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					tri frame = new tri();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public tri() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 0, 414, 250);
		contentPane.add(panel);
		panel.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(300, 27, 86, 20);
		textField.setColumns(10);
		
		
		JLabel lblPulseRate = new JLabel("Pulse Rate:");
		lblPulseRate.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
	
		JLabel lblBeatsPerMinute = new JLabel("beats per minute");
		
		JLabel lblRhythm = new JLabel("Rhythm:");
		lblRhythm.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		final JComboBox comboRythm = new JComboBox();
		comboRythm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JComboBox<String> comboRythm = (JComboBox<String>) e.getSource();
		        String selectedRythm = (String) comboRythm.getSelectedItem();
			}
		});
		comboRythm.setModel(new DefaultComboBoxModel(new String[] {"-choose", "Regular", "Arrhythmia", "Tachycardia", "Bradycardia"}));
		comboRythm.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		textField_1.setColumns(10);
		
		JLabel lblBloodPressure = new JLabel("Blood Pressure:");
		lblBloodPressure.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		JLabel lblSystolic = new JLabel("Systolic (90-119)");
		
		JLabel lblDiastolic = new JLabel("Diastolic (60-79)");
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Tahoma", Font.PLAIN, 17));
		textField_2.setColumns(10);
		
		JLabel label = new JLabel("/");
		label.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Tahoma", Font.PLAIN, 17));
		textField_3.setColumns(10);
		
		JLabel lblLocation = new JLabel("Location:");
		lblLocation.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		JLabel lblNewLabel = new JLabel("Position:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		JLabel lblLocation_1 = new JLabel("Location:");
		lblLocation_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		final JComboBox comboBPLocation = new JComboBox();
		comboBPLocation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JComboBox<String> comboBPLocation = (JComboBox<String>) e.getSource();
		        String selectedBLoc = (String) comboBPLocation.getSelectedItem();
			}
		});
		comboBPLocation.setFont(new Font("Tahoma", Font.PLAIN, 17));
		comboBPLocation.setModel(new DefaultComboBoxModel(new String[] {"-choose", "Left Arm", "Right Arm"}));
		
		final JComboBox comboPLocation = new JComboBox();
		comboPLocation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JComboBox<String> comboPLocation = (JComboBox<String>) e.getSource();
		        String selectedLoc = (String) comboPLocation.getSelectedItem();
			}
		});
		comboPLocation.setModel(new DefaultComboBoxModel(new String[] {"-choose", "Radial", "Carotid", "Femoral", "Pedal", "Brachial", "Apical"}));
		comboPLocation.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		final JComboBox comboBPPosition = new JComboBox();
		comboBPPosition.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JComboBox<String> comboBPPostion = (JComboBox<String>) e.getSource();
		        String selectedBPos = (String) comboBPPosition.getSelectedItem();
			}
		});
		comboBPPosition.setModel(new DefaultComboBoxModel(new String[] {"-choose", "Sitting", "Standing", "Laying"}));
		comboBPPosition.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		JLabel lblRespitoryRate = new JLabel("Respiratory Rate:");
		lblRespitoryRate.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Tahoma", Font.PLAIN, 17));
		textField_4.setColumns(10);
		
		JLabel lblUnitType = new JLabel("Unit Type:");
		lblUnitType.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		final JRadioButton rdbtnUsStandard = new JRadioButton("U.S. Standard");
		
		final JRadioButton rdbtnMetric = new JRadioButton("Metric");
		
		JLabel lblTemperature = new JLabel("Temperature:");
		lblTemperature.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Tahoma", Font.PLAIN, 17));
		textField_5.setColumns(10);
		
		JLabel lblF = new JLabel("(92-103) F");
		
		JLabel lblLocation_2 = new JLabel("Location:");
		lblLocation_2.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		final JComboBox comboTempLocation = new JComboBox();
		comboTempLocation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JComboBox<String> comboTempLocation = (JComboBox<String>) e.getSource();
		        String selectedTLoc = (String) comboTempLocation.getSelectedItem();
			}
		});
		comboTempLocation.setModel(new DefaultComboBoxModel(new String[] {"-choose", "Orally", "Rectally", "Axillary", "By Ear", "By Skin"}));
		comboTempLocation.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Tahoma", Font.PLAIN, 17));
		textField_6.setColumns(10);
		
		JLabel lblHeight = new JLabel("Height:");
		lblHeight.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		textField_7 = new JTextField();
		textField_7.setFont(new Font("Tahoma", Font.PLAIN, 17));
		textField_7.setColumns(10);
		
		JLabel lblWeight = new JLabel("Weight:");
		lblWeight.setFont(new Font("Tahoma", Font.PLAIN, 17));
		
		textField_8 = new JTextField();
		textField_8.setFont(new Font("Tahoma", Font.PLAIN, 17));
		textField_8.setColumns(10);
		
		JLabel lblInches = new JLabel("inches");
		
		JLabel lblPounds = new JLabel("pounds");
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://35.226.84.132:3306/EMR?user=root&password=password\";\r\n" + 
							"    			connection", "root", "password");
					 String pulse=textField.getText();
					 String selectedLoc = (String) comboPLocation.getSelectedItem();
					 String selectedRythm = (String) comboRythm.getSelectedItem();
					 String rythm=textField_1.getText();
					 String sys=textField_2.getText();
					 String dia=textField_3.getText();
					 String selectedBLoc = (String) comboBPLocation.getSelectedItem();
					 String selectedBPos = (String) comboBPPosition.getSelectedItem();
					 String respit=textField_4.getText();
					 String unit = null;
					 if(rdbtnUsStandard.isSelected())
					        unit="US Standard";
					else if(rdbtnMetric.isSelected()) 
					        unit="Metric";
					 String temp=textField_5.getText();
					 String selectedTLoc = (String) comboTempLocation.getSelectedItem();
					 String note=textField_6.getText();
					 String height=textField_7.getText();
					 String weight=textField_8.getText();
					String sql = "UPDATE VITALS SET Pulse_Rate = '"+pulse+"', Location_Pulse = '"+selectedLoc+"', Rythm_Type = '"+selectedRythm+"',  Rythm = '"+rythm+"', Systolic = '"+sys+"', Diastolic = '"+dia+"', BP_Location = '"+selectedBLoc+"', BP_Position = '"+selectedBPos+"', Respiratory_Rate = '"+respit+"', Temperature = '"+temp+"', Unit_Type = '"+unit+"', Temp_Location = '"+selectedTLoc+"', Temp_Note = '"+note+"', Height = '"+height+"', Weight = '"+weight+"'  WHERE patient_id ='" +"'";
					PreparedStatement stmt = con.prepareStatement(sql);
					stmt.executeUpdate(sql);
					JOptionPane.showMessageDialog(null,"Inserted Successfully!");
				} 
				catch(Exception e1) {System.out.print(e1);}
			}
		});
		btnUpdate.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
	}
}
