package org.eclipse.wb.swt;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JTabbedPane;
import javax.swing.JSplitPane;
import javax.swing.JLayeredPane;
import javax.swing.JDesktopPane;
import javax.swing.JToolBar;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;

//import org.eclipse.wb.swt.Order.Order;

import javax.swing.JSeparator;
import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.JEditorPane;
import javax.swing.JRadioButtonMenuItem;
import java.awt.Canvas;
import java.awt.TextArea;
import java.awt.Component;
import javax.swing.Box;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.BorderLayout;
import java.awt.Label;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class LoadPatients {

	private JFrame frmPatients;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;

	/**
	 * Launch the application.
	 * @return 
	 */
	public static void NewScreen() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoadPatients window = new LoadPatients();
					window.frmPatients.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	
	}

	/**
	 * Create the application.
	 */
	public LoadPatients() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPatients = new JFrame();
		frmPatients.setTitle("Patients");
		frmPatients.setResizable(false);
		frmPatients.setBounds(100, 100, 1016, 708);
		
		JLabel lblNewJgoodiesLabel = DefaultComponentFactory.getInstance().createLabel("MENU");
		lblNewJgoodiesLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("Order");	
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		Order1 nw = new Order1 ();
		nw.setVisible(true);
			}
		});
		
		btnNewButton.setBounds(0, 0, 213, 96);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Presciption ");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Medication nw = new Medication();
				nw.setVisible(true);
						
			}
		});
		btnNewButton_1.setBounds(0, 94, 213, 96);
		panel.add(btnNewButton_1);
		
		JButton btnDischargeSummary = new JButton("Discharge Summary");
		btnDischargeSummary.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DischSum nw = new DischSum();
				nw.setVisible(true);
			}
		});
		btnDischargeSummary.setBounds(0, 190, 213, 96);
		panel.add(btnDischargeSummary);
		
		JButton btnImmunization = new JButton("Immunization ");
		btnImmunization.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Immun nw = new Immun();
				nw.setVisible(true);
			}
		});
		btnImmunization.setBounds(0, 286, 213, 96);
		panel.add(btnImmunization);
		
		JButton btnForms = new JButton("Physician Note");
		btnForms.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddHocNote nw = new AddHocNote();
				nw.setVisible(true);
				
			}
		});
		btnForms.setBounds(0, 381, 213, 96);
		panel.add(btnForms);
		
		JButton btnNewButton_2 = new JButton("Depart Process");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Depart nw = new Depart();
				nw.NewScreen();
			}
		});
		btnNewButton_2.setBounds(0, 477, 213, 96);
		panel.add(btnNewButton_2);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		JInternalFrame internalFrame_1 = new JInternalFrame("Vital Signs");
		internalFrame_1.setBorder(null);
		tabbedPane.addTab("Vital Signs", null, internalFrame_1, null);
		internalFrame_1.getContentPane().setLayout(null);
		
		JLabel lblName = new JLabel("Name");
		lblName.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblName.setBounds(64, 30, 46, 14);
		internalFrame_1.getContentPane().add(lblName);
		
		JLabel lblUnit = new JLabel("Unit");
		lblUnit.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblUnit.setBounds(324, 30, 46, 14);
		internalFrame_1.getContentPane().add(lblUnit);
		
		JLabel lblWeight = new JLabel("Weight");
		lblWeight.setBounds(64, 60, 46, 14);
		internalFrame_1.getContentPane().add(lblWeight);
		
		JLabel lblHeight = new JLabel("Height");
		lblHeight.setBounds(64, 85, 46, 14);
		internalFrame_1.getContentPane().add(lblHeight);
		
		JLabel lblBpSystolic = new JLabel("BP Systolic");
		lblBpSystolic.setBounds(64, 121, 66, 14);
		internalFrame_1.getContentPane().add(lblBpSystolic);
		
		JLabel lblPulse = new JLabel("Pulse");
		lblPulse.setBounds(64, 152, 46, 14);
		internalFrame_1.getContentPane().add(lblPulse);
		
		JLabel lblTemperature = new JLabel("Temperature");
		lblTemperature.setBounds(64, 177, 86, 14);
		internalFrame_1.getContentPane().add(lblTemperature);
		
		JLabel lblTemparatureLocation = new JLabel("TemparatureLocation");
		lblTemparatureLocation.setBounds(64, 202, 117, 14);
		internalFrame_1.getContentPane().add(lblTemparatureLocation);
		
		JLabel lblOxygenSaturation = new JLabel("Oxygen Saturation");
		lblOxygenSaturation.setBounds(64, 227, 117, 25);
		internalFrame_1.getContentPane().add(lblOxygenSaturation);
		
		JLabel lblHeadCircumference = new JLabel("BMI");
		lblHeadCircumference.setBounds(64, 263, 46, 14);
		internalFrame_1.getContentPane().add(lblHeadCircumference);
		
		JLabel lblLbs = new JLabel("lbs");
		lblLbs.setBounds(324, 60, 46, 14);
		internalFrame_1.getContentPane().add(lblLbs);
		
		JLabel lblCm = new JLabel("in");
		lblCm.setBounds(324, 85, 46, 14);
		internalFrame_1.getContentPane().add(lblCm);
		
		JLabel lblMmhg = new JLabel("mm/hg");
		lblMmhg.setBounds(324, 121, 46, 14);
		internalFrame_1.getContentPane().add(lblMmhg);
		
		JLabel lblPerMin = new JLabel("per min");
		lblPerMin.setBounds(324, 152, 46, 14);
		internalFrame_1.getContentPane().add(lblPerMin);
		
		JLabel lblF = new JLabel("F");
		lblF.setBounds(324, 177, 46, 14);
		internalFrame_1.getContentPane().add(lblF);
		
		JLabel label = new JLabel("%");
		label.setBounds(324, 232, 46, 14);
		internalFrame_1.getContentPane().add(label);
		
		JLabel lblKgm = new JLabel("kg/m^2");
		lblKgm.setBounds(324, 263, 46, 14);
		internalFrame_1.getContentPane().add(lblKgm);
		
		textField = new JTextField();
		textField.setBounds(431, 57, 86, 20);
		internalFrame_1.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(431, 82, 86, 20);
		internalFrame_1.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(431, 118, 86, 20);
		internalFrame_1.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(431, 149, 86, 20);
		internalFrame_1.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(431, 174, 86, 20);
		internalFrame_1.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		final JComboBox comboTempLoc = new JComboBox();
		comboTempLoc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JComboBox<String> comboTempLoc = (JComboBox<String>) arg0.getSource();
		        String selectedTemparatureLocation = (String) comboTempLoc.getSelectedItem();
			}
		});
		
		
		
		comboTempLoc.setModel(new DefaultComboBoxModel(new String[] {"Axillary", "Oral "}));
		comboTempLoc.setBounds(431, 199, 86, 20);
		internalFrame_1.getContentPane().add(comboTempLoc);
		
		textField_5 = new JTextField();
		textField_5.setBounds(431, 229, 86, 20);
		internalFrame_1.getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(431, 260, 86, 20);
		internalFrame_1.getContentPane().add(textField_6);
		textField_6.setColumns(10);
		
		java.awt.Button button_3 = new java.awt.Button("Ok");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
						try {
							Class.forName("com.mysql.cj.jdbc.Driver");
							Connection con = DriverManager.getConnection("jdbc:mysql://35.226.84.132:3306/EMR?user=root&password=password\";\r\n" + 
									"    			connection", "root", "password");
							 String weight=textField.getText();
							 String Height=textField_1.getText();
							 String BP=textField_2.getText();
							 String pulse=textField_3.getText();
							 String selectedTemparatureLocation = (String) comboTempLoc.getSelectedItem();
							 String Oxygen=textField_5.getText();
							 String BMI=textField_6.getText();			
							 
						String sql = "UPDATE VITALS SET Pulse_Rate = '"+pulse+"',  BP_Location = '"+BP+"', Heigh = '"+Height+"', Weight = '"+weight+"', Temperature = '"+selectedTemparatureLocation+"', Oxygen = '"+Oxygen+"', BMI = '"+BMI+"'";
								PreparedStatement stmt = con.prepareStatement(sql);
								stmt.executeUpdate(sql);
								
		                   JOptionPane.showMessageDialog(null,"Inserted Successfully!");				
	
						} 
						catch(Exception e) {System.out.print(e);}
					}
				});

			
		button_3.setBounds(310, 394, 70, 22);
		internalFrame_1.getContentPane().add(button_3);
		
		JInternalFrame internalFrame = new JInternalFrame("Past Visit");
		tabbedPane.addTab("Past Visit", null, internalFrame, null);
		internalFrame.getContentPane().setLayout(null);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"1", "11", "12", "13", "14"}));
		comboBox_1.setBounds(512, 11, 134, 20);
		internalFrame.getContentPane().add(comboBox_1);
		
		JLabel lblNewLabel = new JLabel("Select Encounter");
		lblNewLabel.setBounds(407, 14, 95, 14);
		internalFrame.getContentPane().add(lblNewLabel);
		GroupLayout groupLayout = new GroupLayout(frmPatients.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(10)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewJgoodiesLabel, GroupLayout.PREFERRED_SIZE, 64, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(panel, GroupLayout.PREFERRED_SIZE, 213, GroupLayout.PREFERRED_SIZE)
							.addGap(10)
							.addComponent(tabbedPane, GroupLayout.PREFERRED_SIZE, 677, GroupLayout.PREFERRED_SIZE))))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(51)
					.addComponent(lblNewJgoodiesLabel, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE)
					.addGap(11)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(panel, GroupLayout.PREFERRED_SIZE, 573, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(13)
							.addComponent(tabbedPane, GroupLayout.PREFERRED_SIZE, 560, GroupLayout.PREFERRED_SIZE))))
		);
		frmPatients.getContentPane().setLayout(groupLayout);
		internalFrame.setVisible(true);
		internalFrame_1.setVisible(true);
	
	
		
	}
	}
