package org.eclipse.wb.swt;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Label;
import javax.swing.DefaultComboBoxModel;
import java.awt.Button;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Order1 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Order1 frame = new Order1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Order1() {
		setResizable(false);
		setBounds(100, 100, 913, 451);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"LAB", "", "ANA", "BMP (Basic Metabolic Panel)", "CBC (Complete Blood Count)", "CMP (Comprehensive Metabolic)", "ESR (Sedimentation Rate)", "Flu( Influenza A and B Screen)", "Glucose Level", "Urine ", "", "", "Radiology", "", "Computed Tomography ", "Fluoroscopy", "Magnetic Resonance Imaging", "Mammography", "Nuclear Medicine ", "Plain x-rays", "Ultrasound", "Venous Access Catheter Placement ", "Vertebroplasty and Kyphoplasty", "", ""}));
		comboBox.setBounds(686, 83, 176, 20);
		contentPane.add(comboBox);
		
		JLabel lblOrderCatalog = new JLabel("Order Catalog");
		lblOrderCatalog.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblOrderCatalog.setBounds(560, 85, 94, 14);
		contentPane.add(lblOrderCatalog);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(95, 124, 721, 216);
		contentPane.add(panel);
		
		Label label_1 = new Label("Dose");
		label_1.setFont(new Font("Dialog", Font.BOLD, 12));
		label_1.setBounds(109, 38, 38, 22);
		panel.add(label_1);
		
		Label label_2 = new Label("Route of Adminstration");
		label_2.setFont(new Font("Dialog", Font.BOLD, 12));
		label_2.setBounds(10, 64, 137, 22);
		panel.add(label_2);
		
		Label label_3 = new Label("PRN");
		label_3.setBounds(78, 88, 69, 22);
		panel.add(label_3);
		
		JLabel lblInfuseOverUnit = new JLabel("Infuse over unit");
		lblInfuseOverUnit.setBounds(48, 116, 99, 14);
		panel.add(lblInfuseOverUnit);
		
		JLabel lblPriorexStat = new JLabel("Prior (ex: STAT or NOW)");
		lblPriorexStat.setBounds(10, 142, 139, 14);
		panel.add(lblPriorexStat);
		
		JLabel lblRequestedStartDatetime = new JLabel("Requested Start Date/Time");
		lblRequestedStartDatetime.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblRequestedStartDatetime.setBounds(10, 168, 137, 14);
		panel.add(lblRequestedStartDatetime);
		
		JLabel lblNewLabel = new JLabel("Drug Form");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel.setBounds(500, 38, 62, 14);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Frequency");
		lblNewLabel_1.setBounds(487, 64, 75, 14);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Duration");
		lblNewLabel_2.setBounds(511, 90, 51, 14);
		panel.add(lblNewLabel_2);
		
		JLabel lblSpecialInstructions = new JLabel("Special Instructions");
		lblSpecialInstructions.setBounds(439, 116, 125, 14);
		panel.add(lblSpecialInstructions);
		
		JLabel lblStopType = new JLabel("Stop type");
		lblStopType.setBounds(493, 142, 69, 14);
		panel.add(lblStopType);
		
		final JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"g (gram) ", "L (liter) ", "lb", "mcg(microgram)", "mG", "mL (milliliter)", "nG (milligram)"}));
		comboBox_1.setBounds(153, 38, 133, 20);
		panel.add(comboBox_1);
		
		final JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"AURICULAR (OTIC) Administration to or by way of the ear. OTIC.  013 C38192 ", "BUCCAL Administration directed toward the cheek, generally from within the mouth. BUCCAL 030 C38193 ", "CONJUNCTIVAL Administration to the conjunctiva, the delicate membrane that lines the eyelids and covers the exposed surface of the eyeball. CONJUNC 068 C38194 ", "CUTANEOUS Administration to the skin. CUTAN 130 C38675 ", "DENTAL Administration to a tooth or teeth. DENTAL 038 C38197 ", "ELECTRO-OSMOSIS Administration of through the diffusion of substance through a membrane in an electric field. EL-OSMOS 357 C38633 ", "ENDOCERVICAL Administration within the canal of the cervix uteri.  Synonymous with the term intracervical.. E-CERVIC 131 C38205 ", "ENDOSINUSIAL Administration within the nasal sinuses of the head. E-SINUS 133 C38206 ", "ENDOTRACHEAL Administration directly into the trachea. E-TRACHE 401 C38208 ", "ENTERAL Administration directly into the intestines. ENTER 313 C38209 ", "EPIDURAL Administration upon or over the dura mater. EPIDUR 009 C38210 ", "EXTRA\u2011AMNIOTIC Administration to the outside of the membrane enveloping the fetus X-AMNI 402 C38211 ", "EXTRACORPOREAL Administration outside of the body. X-CORPOR 057 C38212 ", "HEMODIALYSIS Administration through hemodialysate fluid. HEMO 140 C38200 ", "INFILTRATION Administration that results in substances passing into tissue spaces or into cells. INFIL 361 C38215 ", "INTERSTITIAL Administration to or in the interstices of a tissue. INTERSTIT 088 C38219 ", "INTRA-ABDOMINAL Administration within the abdomen. I-ABDOM 056 C38220 ", "INTRA-AMNIOTIC Administration within the amnion. I-AMNI 060 C38221 ", "INTRA-ARTERIAL Administration within an artery or arteries. I-ARTER 037 C38222 ", "INTRA-ARTICULAR Administration within a joint. I-ARTIC 007 C38223 ", "INTRABILIARY Administration within the bile, bile ducts or gallbladder. I-BILI 362 C38224 ", "INTRABRONCHIAL Administration within a bronchus. I-BRONCHI 067 C38225 ", "INTRABURSAL Administration within a bursa. I-BURSAL 025 C38226 ", "INTRACARDIAC Administration with the heart. I-CARDI 027 C38227 ", "INTRACARTILAGINOUS Administration within a cartilage; endochondral. I-CARTIL 363 C38228 ", "INTRACAUDAL Administration within the cauda equina. I-CAUDAL 413 C38229 ", "INTRACAVERNOUS Administration within a pathologic cavity, such as  occurs in the lung in tuberculosis. I-CAVERN 132 C38230 ", "INTRACAVITARY Administration within a non-pathologic cavity, such as that of the cervix, uterus, or penis, or such as that which is formed as the result of a wound. I-CAVIT 023 C38231 ", "INTRACEREBRAL Administration within the cerebrum. I-CERE 404 C38232 ", "INTRACISTERNAL Administration within the cisterna magna cerebellomedularis. I-CISTERN 405 C38233 ", "INTRACORNEAL Administration within the cornea (the transparent structure forming the anterior part of the fibrous tunic of the eye). I-CORNE 406 C38234 ", "INTRACORONAL, DENTAL Administration of a drug within a portion of a tooth which is covered by enamel and which is separated from the roots by a slightly constricted region known as the neck. I-CORONAL 117 C38217 ", "INTRACORONARY Administration within the coronary arteries. I-CORONARY 119 C38218 ", "INTRACORPORUS CAVERNOSUM Administration within the dilatable spaces of the corporus cavernosa of the penis. I-CORPOR 403 C38235 ", "INTRADERMAL Administration within the dermis. I-DERMAL 008 C38238 ", "INTRADISCAL Administration within a disc. I-DISCAL 121 C38239 ", "INTRADUCTAL Administration within the duct of a gland. I-DUCTAL 123 C38240 ", "INTRADUODENAL Administration within the duodenum. I-DUOD 047 C38241 ", "INTRADURAL Administration within or beneath the dura. I-DURAL 052 C38242 ", "INTRAEPIDERMAL Administration within the epidermis. I-EPIDERM 127 C38243 ", "INTRAESOPHAGEAL Administration within the esophagus. I-ESO 072 C38245 ", "INTRAGASTRIC Administration within the stomach. I-GASTRIC 046 C38246 ", "INTRAGINGIVAL Administration within the gingivae. I-GINGIV 307 C38247 ", "INTRAILEAL Administration within the distal portion of the small intestine, from the jejunum to the cecum. I-ILE 365 C38249 ", "INTRALESIONAL Administration within or introduced directly into a localized lesion. I-LESION 042 C38250 ", "INTRALUMINAL Administration within the lumen of a tube. I-LUMIN 310 C38251 ", "INTRALYMPHATIC Administration within the lymph. I-LYMPHAT 352 C38252 ", "INTRAMEDULLARY Administration within the marrow cavity of a bone. I-MEDUL 408 C38253 ", "INTRAMENINGEAL Administration within the meninges (the three membranes that envelope the brain and spinal cord). I-MENIN 409 C38254 ", "INTRAMUSCULAR Administration within a muscle. IM 005 C28161 ", "INTRAOCULAR Administration within the eye. I-OCUL 036 C38255 ", "INTRAOVARIAN Administration within the ovary. I-OVAR 354 C38256 ", "INTRAPERICARDIAL Administration within the pericardium. I-PERICARD 314 C38257 ", "INTRAPERITONEAL Administration within the peritoneal cavity. I-PERITON 004 C38258 ", "INTRAPLEURAL Administration within the pleura. I-PLEURAL 043 C38259 ", "INTRAPROSTATIC Administration within the prostate gland. I-PROSTAT 061 C38260 ", "INTRAPULMONARY Administration within the lungs or its bronchi. I-PULMON 414 C38261 ", "INTRASINAL Administration within the nasal or periorbital sinuses. I-SINAL 010 C38262 ", "INTRASPINAL Administration within the vertebral column. I-SPINAL 022 C38263 ", "INTRASYNOVIAL Administration within the synovial cavity of a joint. I-SYNOV 019 C38264 ", "INTRATENDINOUS Administration within a tendon. I-TENDIN 049 C38265 ", "INTRATESTICULAR Administration within the testicle. I-TESTIC 110 C38266 ", "INTRATHECAL Administration within the cerebrospinal fluid at any level of the cerebrospinal axis, including injection into the cerebral ventricles. IT 103 C38267 ", "INTRATHORACIC Administration within the thorax (internal to the ribs); synonymous with the term endothoracic. I-THORAC 006 C38207 ", "INTRATUBULAR Administration within the tubules of an organ. I-TUBUL 353 C38268 ", "INTRATUMOR Administration within a tumor. I-TUMOR 020 C38269 ", "INTRATYMPANIC Administration within the aurus media. I-TYMPAN 366 C38270 ", "INTRAUTERINE Administration within the uterus. I-UTER 028 C38272 ", "INTRAVASCULAR Administration within a vessel or vessels. I-VASC 021 C38273 ", "INTRAVENOUS Administration within or into a vein or veins. IV 002 C38276 ", "INTRAVENOUS BOLUS Administration within or into a vein or veins all at once. IV BOLUS 138 C38274 ", "INTRAVENOUS DRIP Administration within or into a vein or veins over a sustained period of time. IV DRIP 137 C38279 ", "INTRAVENTRICULAR Administration within a ventricle. I-VENTRIC 048 C38277 ", "INTRAVESICAL Administration within the bladder. I-VESIC 128 C38278 ", "INTRAVITREAL Administration within the vitreous body of the eye. I-VITRE 311 C38280 ", "IONTOPHORESIS Administration by means of an electric current where ions of soluble salts migrate into the tissues of the body. ION 055 C38203 ", "IRRIGATION Administration to bathe or flush open wounds or body cavities. IRRIG 032 C38281 ", "LARYNGEAL Administration directly upon the larynx. LARYN 364 C38282 ", "NASAL Administration to the nose; administered by way of the nose. NASAL 014 C38284 ", "NASOGASTRIC Administration through the nose and into the stomach, usually by means of a tube. NG 071 C38285 ", "NOT APPLICABLE Routes of administration are not applicable. NA 312 C48623 ", "OCCLUSIVE DRESSING TECHNIQUE Administration by the topical route which is then covered by a dressing which occludes the area. OCCLUS 134 C38286 ", "OPHTHALMIC Administration  to the external eye. OPHTHALM 012 C38287 ", "ORAL Administration to or by way of the mouth. ORAL 001 C38288 ", "OROPHARYNGEAL Administration directly to the mouth and pharynx. ORO 410 C38289 ", "OTHER Administration is different from others on this list. OTHER 135 C38290 ", "PARENTERAL Administration by injection, infusion, or implantation. PAREN 411 C38291 ", "PERCUTANEOUS Administration through the skin. PERCUT 113 C38676 ", "PERIARTICULAR Administration around a joint. P-ARTIC 045 C38292 ", "PERIDURAL Administration to the outside of the dura mater of the spinal cord.. P-DURAL 050 C38677 ", "PERINEURAL Administration surrounding a nerve or nerves. P-NEURAL 412 C38293 ", "PERIODONTAL Administration around a tooth. P-ODONT 040 C38294 ", "RECTAL Administration to the rectum. RECTAL 016 C38295 ", "RESPIRATORY (INHALATION) Administration within the respiratory tract by inhaling orally or nasally for local or systemic effect. RESPIR 136 C38216 ", "RETROBULBAR Administration behind the pons or behind the eyeball. RETRO 034 C38296 ", "SOFT TISSUE Administration into any soft tissue. SOFT TIS 109 C38198 ", "SUBARACHNOID Administration beneath the arachnoid. S-ARACH 066 C38297 ", "SUBCONJUNCTIVAL Administration beneath the conjunctiva. S-CONJUNC 096 C38298 ", "SUBCUTANEOUS Administration beneath the skin; hypodermic.  Synonymous with the term SUBDERMAL. SC 003 C38299 ", "SUBLINGUAL Administration beneath the tongue. SL 024 C38300 ", "SUBMUCOSAL Administration beneath the mucous membrane. S-MUCOS 053 C38301 ", "TOPICAL Administration to a particular spot on the outer surface of the body.  The E2B term TRANSMAMMARY is a subset of the term TOPICAL. TOPIC 011 C38304 ", "TRANSDERMAL Administration through the dermal layer of the skin to the systemic circulation by diffusion. T-DERMAL 358 C38305 ", "TRANSMUCOSAL Administration across the mucosa. T-MUCOS 122 C38283 ", "TRANSPLACENTAL Administration through or across the placenta. T-PLACENT 415 C38307 ", "TRANSTRACHEAL Administration through the wall of the trachea. T-TRACHE 355 C38308 ", "TRANSTYMPANIC Administration across or through the tympanic cavity. T-TYMPAN 124 C38309 ", "UNASSIGNED Route of administration has not yet been assigned. UNAS 400 C38310 ", "UNKNOWN Route of administration is unknown. UNKNOWN 139 C38311 ", "URETERAL Administration into the ureter. URETER 112 C38312 ", "URETHRAL Administration into the urethra. URETH 017 C38271 ", "VAGINAL Administration into the vagina. VAGIN 015 C38313"}));
		comboBox_2.setBounds(153, 66, 285, 20);
		panel.add(comboBox_2);
		
		final JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"Yes", "No"}));
		comboBox_3.setBounds(153, 90, 133, 20);
		panel.add(comboBox_3);
		
		final JComboBox comboBox_4 = new JComboBox();
		comboBox_4.setModel(new DefaultComboBoxModel(new String[] {"U or IU (Write units)", "IV (intravenous)"}));
		comboBox_4.setBounds(153, 116, 133, 20);
		panel.add(comboBox_4);
		
		final JComboBox comboBox_5 = new JComboBox();
		comboBox_5.setModel(new DefaultComboBoxModel(new String[] {"Stat", "Now"}));
		comboBox_5.setBounds(153, 142, 133, 20);
		panel.add(comboBox_5);
		
		final JComboBox comboBox_6 = new JComboBox();
		comboBox_6.setBounds(153, 168, 133, 20);
		panel.add(comboBox_6);
		
		final JComboBox comboBox_7 = new JComboBox();
		comboBox_7.setModel(new DefaultComboBoxModel(new String[] {"AD", "Caps", "Inhal", "IV", "Oral", "Oral Suspension", "Syrup", "Tab", "Valproic Acid Oral ", "", "", ""}));
		comboBox_7.setBounds(568, 38, 133, 20);
		panel.add(comboBox_7);
		
		final JComboBox comboBox_8 = new JComboBox();
		comboBox_8.setModel(new DefaultComboBoxModel(new String[] {"Daily", "DC (Discontinue)", "Hourly", "HS (Write at bedtime or a designated time. Also write out the specific dosing strength and/or quantity)", "QD (Write every day)", "QOD (Write every other day or daily, according to patient\u2019s needs.)", "SQ or SC (Write Subq,subcutaneous)", "TIW (Write twice a week or three times a week)"}));
		comboBox_8.setBounds(568, 64, 133, 20);
		panel.add(comboBox_8);
		
		final JComboBox comboBox_9 = new JComboBox();
		comboBox_9.setModel(new DefaultComboBoxModel(new String[] {"1/5", "1 hour", "24 hours", "48 hours", "72 hours", "1 week", "2 weeks", "3 weeks", "1 month"}));
		comboBox_9.setBounds(568, 90, 133, 20);
		panel.add(comboBox_9);
		
		final JComboBox comboBox_10 = new JComboBox();
		comboBox_10.setBounds(568, 113, 133, 20);
		panel.add(comboBox_10);
		
		final JComboBox comboBox_11 = new JComboBox();
		comboBox_11.setBounds(568, 139, 133, 20);
		panel.add(comboBox_11);
		
		final JComboBox comboBox_12 = new JComboBox();
		comboBox_12.setBounds(568, 165, 133, 20);
		panel.add(comboBox_12);
		
		Button button = new Button("Sign");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Sign nw = new Sign();
				nw.setVisible(true);
			}
		});
		button.setBounds(746, 367, 70, 22);
		contentPane.add(button);
		
		JLabel lblNewLabel_3 = new JLabel("Ordering Physician");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3.setBounds(27, 367, 148, 14);
		contentPane.add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBounds(203, 367, 206, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblOrder = new JLabel("Order");
		lblOrder.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblOrder.setBounds(403, 23, 167, 31);
		contentPane.add(lblOrder);
		
		Button button_1 = new Button("Save");
	
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				try {
					
					
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://35.226.84.132:3306/EMR?user=root&password=password\";\r\n" + 
							"    			connection", "root", "password");
					
					
					 String OrderingPhys=textField.getText();
					 String OrderCatalog = (String) comboBox.getSelectedItem();
					 String Dose = (String) comboBox_1.getSelectedItem();
					 String RouteAministration = (String) comboBox_2.getSelectedItem();
					 String PRN = (String) comboBox_3.getSelectedItem();
					 String InfuseUnit = (String) comboBox_4.getSelectedItem();
					 String Priority = (String) comboBox_5.getSelectedItem();
					 String RequestedStartDate = (String) comboBox_5.getSelectedItem();
					 String DrugForm = (String) comboBox_6.getSelectedItem();
					 String Frequency = (String) comboBox_7.getSelectedItem();
					 String Duration = (String) comboBox_8.getSelectedItem();
					 String SepcialInstruction = (String) comboBox_9.getSelectedItem();
					 String StopType = (String) comboBox_10.getSelectedItem();
		
					 
				String sql = "UPDATE ORDER1 SET OrderingPhys = '"+OrderingPhys+"',  OrderCatalog = '"+OrderCatalog+"', Dose = '"+Dose+"', RouteAministration = '"+RouteAministration+"', PRN = '"+PRN+"', InfuseUnit ="
						+ " '"+InfuseUnit+"',  Priority = '"+ Priority+"', RequestedStartDate = '"+RequestedStartDate+"', DrugForm = '"+DrugForm+"', Frequency = "
								+ "'"+Frequency+"', Duration = '"+Duration+"', SepcialInstruction = "+SepcialInstruction+", StopType = "+StopType+"', " + "'";
								
					PreparedStatement stmt1 = con.prepareStatement(sql);
						PreparedStatement stmt = con.prepareStatement(sql);
						stmt.executeUpdate(sql);
						
                   JOptionPane.showMessageDialog(null,"Information Saved");				

				} 
				catch(Exception e) {System.out.print(e);}
			}
		});
				
		
		
				
		
		button_1.setBounds(500, 367, 70, 22);
		contentPane.add(button_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(10, 69, 721, 357);
		panel_2.setLayout(null);
	}
}
